Building Controllercoin
================

See doc/build-*.md for instructions on building the various
elements of the Controllercoin Core reference implementation of Controllercoin.
